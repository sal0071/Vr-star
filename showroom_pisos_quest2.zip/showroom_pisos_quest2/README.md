# Showroom Virtual de Pisos — protótipo para Meta Quest 2

Este é um protótipo inicial de uma sala 3D navegável com três opções de piso:
- Porcelanato bege
- Porcelanato cinza
- Piso madeirado

## Importante
O projeto é uma demonstração visual, não uma reprodução técnica de um cômodo real. As texturas são geradas no próprio navegador. A seleção do piso altera o revestimento do chão.

## Como testar no PC
1. Extraia o ZIP.
2. Abra a pasta `showroom_pisos_quest2`.
3. O `index.html` precisa ser servido por um servidor web para carregar os módulos do Three.js. Uma forma simples é instalar Python no PC e, dentro da pasta, executar:
   `python -m http.server 8000`
4. Abra `http://localhost:8000` no navegador do PC. Teste com mouse e WASD.

## Como abrir no Meta Quest 2
Para iniciar WebXR, o navegador normalmente exige uma origem segura HTTPS. Para testar com o Quest, publique a pasta em um serviço de hospedagem estática HTTPS (por exemplo, GitHub Pages) ou configure um servidor HTTPS acessível na mesma rede. Depois:
1. Abra o Meta Quest Browser.
2. Acesse o endereço HTTPS do projeto.
3. Aperte `ENTER VR` na página.
4. Aponte o controle para uma das três amostras na parede e aperte o gatilho para mudar o piso.
5. Use o analógico para se deslocar; o mapeamento do analógico pode variar conforme o navegador/controle.

## Arquivos
- `index.html`: cena 3D, materiais e interação VR.
- `README.md`: instruções de execução.

## Próximos aprimoramentos possíveis
- Importar texturas reais dos pisos vendidos pela loja.
- Adicionar botão para trocar parede, rodapé, iluminação e ambiente.
- Criar modelos mais realistas de banheiro, cozinha e sala.
- Reconstruir a casa do cliente a partir de fotos ou medidas.
- Empacotar como PWA após validar o funcionamento no navegador.
